package com.auth.authentication.Controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;





@RestController
@RequestMapping("/api")
public class OauthController {


    @GetMapping("/")
    public ResponseEntity<String>  HelloWelcome() {
        return ResponseEntity.ok("welcome to Oauth apis");
    }

    @PutMapping("/contact-us")
    public ResponseEntity<String> ContactPage(){
        return ResponseEntity.ok("welcome to contact page of website");


    }
    

}
